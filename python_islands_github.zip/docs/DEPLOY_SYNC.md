# 啟用 GitHub Pages 的課堂同步

`index.html` 可以獨立開啟，也能直接放上 GitHub Pages。跨裝置的課堂進度另外由本部署包的 Cloudflare Worker 與 D1 儲存。GitHub Pages 負責顯示教材，Worker 負責教師密碼驗證與進度 API，D1 保存課堂記錄。

本部署包已包含後端程式與資料表，但尚未替您的帳號建立或部署雲端資源。只上傳 `index.html` 時，學生可以自由練習；完成下列設定後，老師才能在另一台裝置收到進度。

## 需要準備

- 已能開啟的 GitHub Pages 網頁，例如 `https://your-account.github.io/python-islands/`。
- 您自己管理的 Cloudflare 帳號。
- 安裝仍受 Wrangler 支援之 Node.js 22 或更新版本的電腦，以及終端機／命令提示字元。Cloudflare 目前列出的 Wrangler 作業系統為 Windows 11、macOS 13.5 以上，或支援 glibc 2.35 的 Linux。
- 下載包中的完整 `backend` 資料夾。

下列指令都在 `backend` 資料夾執行。Cloudflare 帳號登入由您在自己的瀏覽器完成，不需要把密碼、API token 或帳號憑證貼到 HTML 或 GitHub。

## 1. 安裝部署工具並登入

```sh
cd backend
npm install
npx wrangler login
```

`wrangler` 是 Cloudflare 官方部署工具。登入完成後，再繼續建立資料庫。

## 2. 建立 D1 資料庫

```sh
npx wrangler d1 create alam-python-islands
```

記下工具回傳的 `database_id`。開啟 `wrangler.jsonc`，將 `REPLACE_WITH_D1_DATABASE_ID` 換成剛取得的 ID。若工具詢問是否更新設定，可以接受更新，然後確認下列三個欄位保持一致：

```json
{
  "binding": "DB",
  "database_name": "alam-python-islands",
  "database_id": "剛取得的實際資料庫 ID",
  "migrations_dir": "migrations"
}
```

`DB` 是程式使用的綁定名稱，請保留不變。`database_id` 是資源識別碼，不是教師密碼。

## 3. 設定允許連線的網頁來源

在同一個 `wrangler.jsonc`，修改 `vars`：

```json
{
  "ALLOWED_ORIGINS": "https://your-account.github.io",
  "ALLOW_FILE_ORIGIN": "true"
}
```

**`ALLOWED_ORIGINS` 只填來源，不填儲存庫路徑，也不要在最後加斜線。**

| 教材實際網址 | `ALLOWED_ORIGINS` 的正確內容 |
| --- | --- |
| `https://your-account.github.io/python-islands/` | `https://your-account.github.io` |
| `https://learn.example.edu.tw/python/` | `https://learn.example.edu.tw` |
| 同時使用 GitHub 與自訂網域 | `https://your-account.github.io,https://learn.example.edu.tw` |

來源必須是完整的 HTTPS origin。萬用字元 `*`、`https://*.github.io`、含 `/python-islands/` 路徑或帳號密碼的 URL 都不會授權。不同儲存庫若使用同一個 `your-account.github.io`，在瀏覽器中屬於同一來源；課堂內容仍由各自的課堂代碼與權杖隔離。

`ALLOW_FILE_ORIGIN` 設為字串 `"true"`，會允許下載後用 `file://` 開啟的 HTML 連線。這類請求的來源是 `null`，無法辨識具體是哪個本機檔案，但教師及學生 API 仍需通過各自的授權。若全部學生都使用 GitHub Pages，可改成字串 `"false"`。

## 4. 建立正式資料表

確認資料庫 ID 填好後，執行：

```sh
npx wrangler d1 migrations apply DB --remote
```

工具會套用 `migrations/0001_initial.sql`，建立課堂、學生、教師登入、五島進度與操作頻率記錄。此指令的 `--remote` 表示修改正式資料庫。若只要測試本機，可使用 `npm run db:migrate:local`。

## 5. 發布同步服務

```sh
npx wrangler deploy
```

成功後，工具會回傳您的 Worker 網址，形式如：

```text
https://alam-python-islands-sync.您的子網域.workers.dev
```

這裡的網址只是格式範例，請使用部署結果提供的實際網址。之後修改允許來源或後端程式，都需要再次執行 `npx wrangler deploy`。

## 6. 確認服務就緒

用瀏覽器開啟實際 Worker 網址，加上 `/api/health`。資料庫與服務正常時會看到：

```json
{
  "ok": true,
  "app": "alam-python-islands",
  "version": 1,
  "maxSteps": [4, 4, 3, 6, 3]
}
```

Worker 首頁只顯示服務資訊，不是教材畫面。學生應開啟 GitHub Pages 上的 `index.html`。

## 7. 把服務網址接回教材

在教材的教師入口開啟「連線設定」，貼入實際 Worker 的 HTTPS 網址。只填網址的 origin，例如 `https://alam-python-islands-sync.您的子網域.workers.dev`，不要加 `/api` 或 `/api/health`。

先執行教材的連線測試。確認成功後，使用網頁提供的下載功能產生已設定連線的 `index.html`，再以新檔案覆蓋 GitHub 儲存庫中的 `index.html`。這樣學生開啟同一份網頁時，也會使用相同的同步服務；只在老師自己的瀏覽器保存設定，不會自動修改 GitHub 上的檔案。

服務網址可以公開，**教師密碼與教師登入權杖不能寫進 HTML**。教材只保存服務位置，老師在建立課堂時自行設定密碼。

## 8. 做一次兩台裝置測試

1. 老師開啟已更新的 GitHub Pages 網頁，從右上角建立新課堂並設定教師密碼。
2. 記下課堂代碼，或複製學生連結。
3. 用另一台電腦、平板或手機開啟學生連結，輸入測試學號。
4. 完成一座島，再回到老師的進度看板。看板每 5 秒更新一次，應顯示該學號所在島嶼、完成度與作答次數。
5. 重新整理學生頁面，確認同一學號的進度可以恢復。

同一學號在另一台裝置登入時，老師可使用「解除綁定」保留進度並允許新裝置加入。學號是課堂識別，不等同學校正式身分驗證；本工具的進度用於教學觀察。

## 常見狀況

| 畫面或錯誤 | 檢查方式 |
| --- | --- |
| 教材顯示尚未設定同步服務 | 先部署 Worker，再設定網址並重新上傳已設定的 HTML。 |
| Worker 首頁可以開，教材卻連不上 | 檢查 `ALLOWED_ORIGINS` 是否符合 GitHub Pages 的實際 origin，修改後重新部署。若網頁跳轉到自訂網域，應加入跳轉後的 origin。 |
| `ORIGIN_REJECTED`／瀏覽器顯示 CORS 錯誤 | 來源未列入白名單，或錯填了路徑、尾端斜線、HTTP 或萬用字元。 |
| 本機 HTML 無法同步，但 GitHub 上可以 | 檢查 `ALLOW_FILE_ORIGIN` 是否為字串 `"true"`，並確認本機檔案也保存了服務網址。 |
| `DATABASE_UNAVAILABLE` | 確認 D1 綁定名稱是 `DB`，且部署設定包含正確資料庫 ID。 |
| `/api/health` 回 `SERVICE_ERROR` | 確認已對同一個資料庫執行遠端 migrations；再查看 Cloudflare Worker 記錄。 |
| `LOGIN_FAILED` | 課堂代碼或教師密碼不正確，或課堂已到期。 |
| `DEVICE_CONFLICT` | 同學號已綁定另一個裝置，請由老師解除綁定。 |
| `ROOM_CLOSED` | 老師已暫停課堂，可在看板重新開放。 |
| `RATE_LIMITED` | 操作過於頻繁，依回應的等待時間稍後重試。 |
| 修改檔案後仍看到舊版 | 等待 GitHub Pages 發布完成，再重新整理；必要時使用瀏覽器的強制重新整理。 |

## 本版本的資料與使用範圍

- 教師密碼以 PBKDF2-SHA256 加上獨立 salt 雜湊儲存。資料庫不保存明文密碼或明文登入權杖。
- 教師登入最長 12 小時；修改密碼會讓舊的教師登入失效。
- 每課堂最多 200 位學生，課堂建立 30 天後停止接受存取。
- 到期資料會在下一次建立課堂時清理；本版本沒有另外建立每日清理排程。
- 學生無權讀取其他學生的名單與進度。伺服器只允許持有該課堂教師權杖的人讀取看板資料。
- CORS 白名單限制瀏覽器來源，不能取代教師密碼與 API 授權。後端另有建立課堂、加入與教師登入的操作頻率限制。
- Cloudflare 的可用額度與費用依您帳號當下方案及用量計算，這份部署包不保證服務永遠免費。

## 官方操作文件

- [GitHub Pages 建立網站](https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site)：Pages 提供靜態網頁，課堂資料另外使用 API 服務。
- [Cloudflare D1 入門](https://developers.cloudflare.com/d1/get-started/)：建立資料庫與綁定。
- [Wrangler D1 指令](https://developers.cloudflare.com/workers/wrangler/commands/d1/)：建立資料庫、套用 migrations。
- [Wrangler 設定](https://developers.cloudflare.com/workers/wrangler/configuration/)：Worker、環境變數及 D1 綁定。
- [Wrangler 指令](https://developers.cloudflare.com/workers/wrangler/commands/)：發布與更新服務。
- [Wrangler 安裝與系統需求](https://developers.cloudflare.com/workers/wrangler/install-and-update/)：工具安裝與目前支援環境。

本文件整理日期：2026 年 11 月 23 日。上述連線與容量說明以本部署包程式為準。
