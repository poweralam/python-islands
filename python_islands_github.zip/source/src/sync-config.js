/* Portable classroom configuration. Settings never come from query parameters.
   Downloads use the original, unmodified HTML supplied at application startup. */
(() => {
  'use strict';
  const EXPECTED_STEPS = [4, 4, 3, 6, 3];
  const APP_ID = 'alam-python-islands';
  const COURSE = 'python-basics-ai-v1';
  const isLocalHost = host => ['localhost', '127.0.0.1', '[::1]'].includes(host);

  function checkedURL(value, label, originOnly = false) {
    const text = String(value || '').trim();
    if (!text) return '';
    let url;
    try { url = new URL(text); } catch { throw new Error(`${label}格式不正確，請貼上完整網址。`); }
    if (url.username || url.password) throw new Error(`${label}不能包含帳號或密碼。`);
    if (url.protocol !== 'https:' && !(url.protocol === 'http:' && isLocalHost(url.hostname))) {
      throw new Error(`${label}需要使用 HTTPS；本機開發的 localhost 可使用 HTTP。`);
    }
    if (originOnly && ((url.pathname && url.pathname !== '/') || url.search || url.hash)) {
      throw new Error('課堂服務網址只需填寫主網址，不要附加 /api、其他路徑或參數。');
    }
    if (originOnly) return url.origin;
    url.search = '';
    url.hash = '';
    return url.href;
  }

  function safeConfiguration(value) {
    if (!value || typeof value !== 'object') return { apiBase: '', studentPageUrl: '' };
    return {
      apiBase: checkedURL(value.apiBase, '課堂服務網址', true),
      studentPageUrl: checkedURL(value.studentPageUrl, '學生網頁網址')
    };
  }

  function create({ sourceHTML, beforeChange = () => true, onChange = () => {} } = {}) {
    const originalSource = typeof sourceHTML === 'string' ? sourceHTML : '';
    let baked = { apiBase: '', studentPageUrl: '' }, initialError = '';
    try {
      const tag = document.getElementById('classroom-config');
      baked = safeConfiguration(tag ? JSON.parse(tag.textContent || '{}') : {});
    } catch (error) { initialError = `網頁內的連線設定無法使用：${error.message}`; }
    const storageKey = `alam-python-sync-v1:${location.origin}:${location.pathname}`;
    let current = { ...baked };
    try {
      const saved = JSON.parse(localStorage.getItem(storageKey) || 'null');
      // A new embedded configuration takes precedence over an older browser override.
      if (saved && saved.bakedApiBase === baked.apiBase && saved.bakedStudentPageUrl === baked.studentPageUrl) {
        current = safeConfiguration(saved);
      }
    } catch { /* Storage may be unavailable, or an older setting may be invalid. */ }

    const dialog = document.createElement('dialog');
    dialog.className = 'modal small-modal island-sync-dialog';
    dialog.id = 'sync-config-dialog';
    dialog.setAttribute('aria-labelledby', 'sync-config-title');
    dialog.innerHTML = `
      <button type="button" class="modal-close" aria-label="關閉課堂連線設定">×</button>
      <p class="eyebrow">CLASSROOM CONNECTION</p>
      <h2 id="sync-config-title">課堂連線設定</h2>
      <p class="muted">GitHub Pages 顯示學習網頁；課堂服務負責儲存進度與驗證教師密碼。</p>
      <label for="sync-config-endpoint">課堂服務網址</label>
      <input id="sync-config-endpoint" type="url" inputmode="url" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="https://您的服務名稱.workers.dev" aria-describedby="sync-config-endpoint-help">
      <p id="sync-config-endpoint-help" class="form-note">填入課堂服務的主網址，不含 /api 路徑。留白時使用離線自由練習。</p>
      <label for="sync-config-page">學生網頁網址（選填）</label>
      <input id="sync-config-page" type="url" inputmode="url" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="https://帳號.github.io/專案名稱/" aria-describedby="sync-config-page-help">
      <p id="sync-config-page-help" class="form-note">請保留 GitHub 專案路徑。直接開啟本機 HTML 時，先填這個網址，才能複製學生連結。</p>
      <div class="island-sync-actions">
        <button type="button" class="secondary" data-sync-action="test">測試連線</button>
        <button type="button" class="primary" data-sync-action="save">儲存這台裝置設定</button>
      </div>
      <p class="island-sync-status" role="status" aria-live="polite"></p>
      <div class="island-sync-export">
        <strong>讓全班使用相同設定</strong>
        <p class="form-note">上傳設定好的 index.html 到 GitHub，學生才會共用這個服務網址。</p>
        <button type="button" class="secondary full" data-sync-action="download">下載已設定的 index.html</button>
        <p class="form-note">下載檔只包含教材與連線網址，不會包含學號、教師密碼或登入狀態。</p>
      </div>`;
    document.body.append(dialog);
    const styles = document.createElement('style');
    styles.textContent = `.island-sync-dialog{width:min(520px,calc(100% - 28px))}.island-sync-dialog .modal-close{font-size:25px}.island-sync-dialog .island-sync-actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:20px}.island-sync-dialog .island-sync-actions button{flex:1;min-width:150px;font-size:14px}.island-sync-dialog .island-sync-status{min-height:44px;color:#786782;font-size:14px;line-height:1.75;margin:15px 0;white-space:pre-line;overflow-wrap:anywhere}.island-sync-dialog .island-sync-status[data-kind="success"]{color:#47715c}.island-sync-dialog .island-sync-status[data-kind="error"]{color:#935f45}.island-sync-dialog .island-sync-export{padding:18px 0 0;border-top:1px solid #e9e1f0}.island-sync-dialog .island-sync-export strong{font-size:15px;color:#786486}.island-sync-dialog .island-sync-export .form-note:last-child{margin-bottom:0}.island-sync-dialog input{font-size:14px}.island-sync-dialog .form-note{font-size:13px;line-height:1.8}`;
    document.head.append(styles);

    const endpointInput = dialog.querySelector('#sync-config-endpoint');
    const pageInput = dialog.querySelector('#sync-config-page');
    const status = dialog.querySelector('.island-sync-status');
    const testButton = dialog.querySelector('[data-sync-action="test"]');
    const saveButton = dialog.querySelector('[data-sync-action="save"]');
    const downloadButton = dialog.querySelector('[data-sync-action="download"]');
    let testController = null, testing = false, saving = false;
    let lastTestedEndpoint = '';

    function showStatus(message, kind = '') {
      status.textContent = message;
      status.dataset.kind = kind;
    }
    function values() {
      return {
        apiBase: checkedURL(endpointInput.value, '課堂服務網址', true),
        studentPageUrl: checkedURL(pageInput.value, '學生網頁網址')
      };
    }
    function statusSummary() {
      if (initialError) return showStatus(initialError, 'error');
      if (!current.apiBase) return showStatus('尚未設定課堂服務。五座小島可先自由練習；跨裝置進度暫未同步。');
      if (current.apiBase !== baked.apiBase || current.studentPageUrl !== baked.studentPageUrl) {
        showStatus('這台裝置已設定服務網址。要讓學生共用設定，請下載並上傳設定好的 index.html。');
      } else {
        showStatus('這份 HTML 已包含服務網址。可先測試連線，再建立或加入課堂。');
      }
    }
    function renderValues() {
      endpointInput.value = current.apiBase;
      pageInput.value = current.studentPageUrl;
      statusSummary();
    }
    function setTesting(value) {
      testing = value;
      testButton.disabled = value;
      saveButton.disabled = value || saving;
      downloadButton.disabled = value;
      testButton.textContent = value ? '正在測試…' : '測試連線';
    }

    async function testConnection() {
      if (testing) return;
      let candidate;
      try {
        candidate = values();
        if (!candidate.apiBase) throw new Error('請先填入課堂服務網址。若只需要自由練習，可直接關閉設定視窗。');
      } catch (error) { showStatus(error.message, 'error'); return; }
      setTesting(true);
      showStatus('正在確認課堂服務是否可用…');
      const controller = new AbortController();
      testController = controller;
      const timeout = setTimeout(() => controller.abort(), 10000);
      try {
        const response = await fetch(`${candidate.apiBase}/api/health`, {
          method: 'GET', headers: { Accept: 'application/json' }, credentials: 'omit',
          cache: 'no-store', signal: controller.signal
        });
        let data;
        try { data = await response.json(); } catch { throw new Error('服務沒有回傳課堂資料。請確認填入的是課堂 Worker 網址，而不是 GitHub 網頁網址。'); }
        if (!response.ok) {
          const detail = typeof data?.error === 'string' ? data.error : '服務暫時無法使用。';
          throw new Error(`${detail} 請檢查資料庫設定，以及服務是否允許這個網頁來源。`);
        }
        if (data?.ok !== true || data.app !== APP_ID || data.version !== 1 ||
            !Array.isArray(data.maxSteps) || data.maxSteps.length !== EXPECTED_STEPS.length ||
            data.maxSteps.some((step, i) => step !== EXPECTED_STEPS[i])) {
          throw new Error('這個服務與目前的 Python 星島教材版本不相符。請使用部署包中的同步後端。');
        }
        lastTestedEndpoint = candidate.apiBase;
        showStatus('連線成功，課堂服務與五島活動版本相符。請儲存設定，或下載已設定的 HTML。', 'success');
      } catch (error) {
        if (controller.signal.aborted) showStatus('測試已取消或超過 10 秒。請確認服務網址與網路，再試一次。', 'error');
        else if (error instanceof TypeError) showStatus('目前無法連線。請確認網路，並在後端 ALLOWED_ORIGINS 加入此 GitHub 網頁的來源；本機 HTML 需開啟 ALLOW_FILE_ORIGIN。', 'error');
        else showStatus(error.message || '連線測試未完成，請稍後再試。', 'error');
      } finally {
        clearTimeout(timeout);
        if (testController === controller) testController = null;
        setTesting(false);
      }
    }

    async function saveSettings() {
      if (saving || testing) return;
      let candidate;
      try { candidate = values(); } catch (error) { showStatus(error.message, 'error'); return; }
      saving = true;
      saveButton.disabled = true;
      try {
        const changed = candidate.apiBase !== current.apiBase || candidate.studentPageUrl !== current.studentPageUrl;
        if (changed && await beforeChange(candidate) === false) {
          showStatus('請先離開學生課堂並登出教師觀測站，再更改連線設定。', 'error');
          return;
        }
        let persistent = true;
        try {
          localStorage.setItem(storageKey, JSON.stringify({
            ...candidate, bakedApiBase: baked.apiBase, bakedStudentPageUrl: baked.studentPageUrl
          }));
        } catch { persistent = false; }
        current = { ...candidate };
        initialError = '';
        endpointInput.value = candidate.apiBase;
        pageInput.value = candidate.studentPageUrl;
        if (changed) await onChange(candidate.apiBase, { ...candidate });
        if (!persistent) {
          showStatus('這個瀏覽器無法保留設定。目前頁面可使用新設定，請下載已設定的 HTML，避免關閉後遺失。', 'error');
        } else if (!current.apiBase) {
          showStatus('已改為自由練習模式。學習進度保留在這個瀏覽器，不會傳送到課堂服務。', 'success');
        } else {
          showStatus(`${lastTestedEndpoint === current.apiBase ? '已測試並儲存。' : '已儲存網址，尚未確認服務是否可用。'}請下載已設定的 index.html 並上傳 GitHub，讓學生共用此設定。`, 'success');
        }
      } catch (error) {
        showStatus(error.message || '未能完成設定，請稍後再試。', 'error');
      } finally {
        saving = false;
        saveButton.disabled = testing;
      }
    }

    function downloadConfiguredHTML() {
      let candidate;
      try {
        candidate = values();
        if (!originalSource || !originalSource.includes('classroom-config')) {
          throw new Error('目前無法建立完整下載檔。請重新開啟原始 index.html，再設定一次。');
        }
        const output = new DOMParser().parseFromString(originalSource, 'text/html');
        const configurationTag = output.getElementById('classroom-config');
        if (!configurationTag || configurationTag.tagName !== 'SCRIPT') throw new Error('原始 HTML 缺少連線設定區塊，無法產生下載檔。');
        configurationTag.textContent = JSON.stringify({
          apiBase: candidate.apiBase, studentPageUrl: candidate.studentPageUrl, course: COURSE
        }).replace(/</g, '\\u003c');
        const content = '<!doctype html>\n' + output.documentElement.outerHTML;
        const blobURL = URL.createObjectURL(new Blob([content], { type: 'text/html;charset=utf-8' }));
        const link = document.createElement('a');
        link.href = blobURL;
        link.download = 'index.html';
        document.body.append(link);
        link.click();
        link.remove();
        setTimeout(() => URL.revokeObjectURL(blobURL), 5000);
        showStatus(candidate.apiBase ? '已下載 index.html。請用這個檔案更新 GitHub，學生就會使用檔案內的連線網址。' : '已下載離線練習版 index.html。這份檔案尚未設定課堂同步服務。', 'success');
      } catch (error) { showStatus(error.message || '無法產生下載檔，請稍後再試。', 'error'); }
    }

    testButton.addEventListener('click', testConnection);
    saveButton.addEventListener('click', saveSettings);
    downloadButton.addEventListener('click', downloadConfiguredHTML);
    dialog.querySelector('.modal-close').addEventListener('click', () => dialog.close());
    dialog.addEventListener('close', () => { if (testController) testController.abort(); });
    endpointInput.addEventListener('input', () => { lastTestedEndpoint = ''; });

    return {
      get endpoint() { return current.apiBase; },
      get studentPageUrl() { return current.studentPageUrl; },
      get bakedEndpoint() { return baked.apiBase; },
      open() {
        renderValues();
        if (!dialog.open) dialog.showModal();
        endpointInput.focus();
      },
      showStatus,
      buildStudentLink(roomCode) {
        if (!/^[A-Za-z0-9]{6}$/.test(String(roomCode))) throw new Error('課堂代碼格式不正確，請重新開啟教師觀測站。');
        let base = current.studentPageUrl;
        if (!base && /^https?:$/.test(location.protocol)) base = checkedURL(location.href, '目前網頁網址');
        if (!base) throw new Error('本機 HTML 沒有可分享的網頁網址。請在「課堂連線設定」填入 GitHub Pages 學生網頁網址。');
        const url = new URL(base);
        url.search = '';
        url.hash = '';
        url.searchParams.set('room', String(roomCode).toUpperCase());
        return url.href;
      }
    };
  }
  window.IslandSyncConfig = Object.freeze({ create });
})();
