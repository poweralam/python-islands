/* Standalone 3D island scene. All geometry is projected from world-space vertices.
   No images, fonts, external packages, timers, or persistent animation loops. */
(() => {
  'use strict';
  const TAU = Math.PI * 2;
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const mix = (a, b, t) => a + (b - a) * t;
  const add = (a, b) => a.map((v, i) => v + b[i]);
  const sub = (a, b) => a.map((v, i) => v - b[i]);
  const mul = (a, s) => a.map(v => v * s);
  const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
  const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
  const norm = a => mul(a, 1 / (Math.hypot(...a) || 1));
  const LIGHT = norm([-0.45, 0.85, 0.5]);
  const ISLANDS = [
    { key: 'A', title: '資料型態', pos: [-3.9, 0.05, 0.25], color: '#b6dfcc', edge: '#b8c9e1' },
    { key: 'B', title: '輸入與運算', pos: [-1.9, 0.15, -3.35], color: '#c2d8ed', edge: '#c9c4e6' },
    { key: 'C', title: '條件判斷', pos: [2.35, 0.12, -2.8], color: '#d0c5eb', edge: '#b6cae5' },
    { key: 'D', title: '迴圈與串列', pos: [3.5, -0.03, 1.45], color: '#f1cebc', edge: '#d9bfce' },
    { key: 'E', title: 'AI與模組', pos: [-0.65, -0.04, 3.7], color: '#eadcaa', edge: '#c9cadc' }
  ];
  const shade = (hex, amount) => {
    const n = parseInt(hex.slice(1), 16);
    return `rgb(${[n >> 16 & 255, n >> 8 & 255, n & 255].map(v => Math.round(clamp(v * amount, 0, 255))).join(',')})`;
  };

  class Geometry {
    constructor() { this.faces = []; }
    face(points, color, flat = false) {
      const normal = norm(cross(sub(points[1], points[0]), sub(points[2], points[0])));
      const brightness = flat ? 1 : 0.79 + 0.25 * Math.max(0, dot(normal, LIGHT));
      this.faces.push({ points, fill: shade(color, brightness) });
    }
    box(c, size, color) {
      const [x, y, z] = c, [w, h, d] = size.map(v => v / 2);
      const p = [[x-w,y-h,z-d],[x+w,y-h,z-d],[x+w,y+h,z-d],[x-w,y+h,z-d],
        [x-w,y-h,z+d],[x+w,y-h,z+d],[x+w,y+h,z+d],[x-w,y+h,z+d]];
      [[0,3,2,1],[4,5,6,7],[0,4,7,3],[1,2,6,5],[3,7,6,2],[0,1,5,4]]
        .forEach(f => this.face(f.map(i => p[i]), color));
    }
    sphere(c, radii, color, segments = 10, rings = 6) {
      const p = (u, v) => [c[0] + radii[0]*Math.sin(v)*Math.cos(u), c[1] + radii[1]*Math.cos(v), c[2] + radii[2]*Math.sin(v)*Math.sin(u)];
      for (let j=0;j<rings;j++) for(let i=0;i<segments;i++) {
        const u=i*TAU/segments, un=(i+1)*TAU/segments, v=j*Math.PI/rings, vn=(j+1)*Math.PI/rings;
        const a=p(u,v),b=p(un,v),d=p(u,vn),e=p(un,vn);
        if (j===0) this.face([a,e,d],color);
        else if(j===rings-1) this.face([a,b,d],color);
        else this.face([a,b,e,d],color);
      }
    }
    cylinder(a, b, radiusA, radiusB, color, segments = 12, cap = true) {
      const axis=norm(sub(b,a));
      const u=norm(cross(axis,Math.abs(axis[1])>.9?[1,0,0]:[0,1,0])), v=cross(axis,u);
      const ring=(center,radius,k)=>add(center,add(mul(u,Math.cos(k*TAU/segments)*radius),mul(v,Math.sin(k*TAU/segments)*radius)));
      for(let i=0;i<segments;i++) {
        const a1=ring(a,radiusA,i),a2=ring(a,radiusA,i+1),b1=ring(b,radiusB,i),b2=ring(b,radiusB,i+1);
        this.face([a1,a2,b2,b1],color);
        if(cap) {this.face([a,a2,a1],color);this.face([b,b1,b2],color);}
      }
    }
    ring(center, radius, thickness, color, segments=32, plane='xz') {
      const point=(angle,r) => plane==='xy' ? [center[0]+Math.cos(angle)*r,center[1]+Math.sin(angle)*r,center[2]] : [center[0]+Math.cos(angle)*r,center[1],center[2]+Math.sin(angle)*r];
      for(let i=0;i<segments;i++) {
        const a=i*TAU/segments,b=(i+1)*TAU/segments;
        this.face([point(a,radius-thickness),point(a,radius+thickness),point(b,radius+thickness),point(b,radius-thickness)],color,true);
      }
    }
    crystal(c, r, height, color) {
      const ring=Array.from({length:6},(_,i)=>[c[0]+Math.cos(i*TAU/6)*r,c[1]+height*.42,c[2]+Math.sin(i*TAU/6)*r]);
      for(let i=0;i<6;i++) {
        this.face([[c[0],c[1]+height,c[2]],ring[i],ring[(i+1)%6]],color);
        this.face([[c[0],c[1],c[2]],ring[(i+1)%6],ring[i]],color);
      }
    }
    star(c, radius, color, rotation=0) {
      const ps=Array.from({length:10},(_,i)=>{const a=-Math.PI/2+i*Math.PI/5+rotation,r=i%2?radius*.46:radius;return [c[0]+Math.cos(a)*r,c[1]-Math.sin(a)*r,c[2]];});
      for(let i=0;i<10;i++) this.face([c,ps[i],ps[(i+1)%10]],color,true);
    }
  }

  class IslandScene {
    constructor({ canvas, labelLayer, onSelect }) {
      this.canvas=canvas;
      this.ctx=canvas.getContext('2d',{alpha:true});
      this.labelLayer=labelLayer;
      this.onSelect=onSelect || (()=>{});
      this.yaw=-.04; this.pitch=.71; this.zoomLevel=1; this.selected=0;
      this.completed=[false,false,false,false,false];
      this.low=window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      this.travel=null; this.traveler=this._travelerPosition(0);
      this.frame=0;this.dead=false;this.pointers=new Map();this.cleanups=[];
      this.base=this._buildWorld();
      this._labels();this._listen();
      if (typeof ResizeObserver!=='undefined') {
        this.observer=new ResizeObserver(()=>this.resize());
        this.observer.observe(canvas.parentElement || canvas);
      }
      this.resize();
    }

    _labels() {
      const existing=document.getElementById('island-scene-styles');
      if(!existing) {
        const style=document.createElement('style');style.id='island-scene-styles';
        style.textContent=`#island-labels{position:absolute;inset:0;pointer-events:none;overflow:hidden}.island-marker{position:absolute;left:0;top:0;display:flex;gap:9px;align-items:center;width:132px;min-height:50px;padding:8px 11px;border:1px solid rgba(255,255,255,.95);border-radius:16px;background:rgba(255,255,255,.94);box-shadow:0 5px 18px #6157880f;transform-origin:50% 0;pointer-events:auto;color:#544b70;font:500 14px/1.2 system-ui,-apple-system,BlinkMacSystemFont,"Noto Sans TC",sans-serif;text-align:left;cursor:pointer;touch-action:manipulation}.island-marker:hover{background:#fff;border-color:#aea0ce}.island-marker:focus-visible{outline:3px solid #6f6099;outline-offset:4px}.island-marker[aria-pressed="true"]{border-color:#8b78b3;background:#fff;box-shadow:0 4px 18px #75609b24}.island-marker .island-letter{display:grid;place-items:center;flex-shrink:0;width:29px;height:29px;border-radius:10px;background:var(--island-tint);color:#554966;font-size:15px;font-weight:800}.island-marker .island-caption{display:flex;flex-direction:column;gap:4px;white-space:nowrap}.island-marker .island-caption small{font-size:12px;font-weight:500;color:#756b85}.island-marker .island-check{position:absolute;right:-4px;top:-6px;width:21px;height:21px;display:grid;place-items:center;border:2px solid #fff;border-radius:50%;background:#649b81;color:#fff;font-size:12px;font-weight:800}.island-marker .island-check[hidden]{display:none}@media(max-width:600px){.island-marker{width:120px;min-height:45px;gap:7px;padding:7px 9px}.island-marker .island-letter{width:25px;height:25px;font-size:14px}.island-marker .island-caption{font-size:13px;gap:3px}.island-marker .island-caption small{font-size:12px}}`;
        document.head.appendChild(style);
      }
      this.labelLayer.replaceChildren();
      this.labels=ISLANDS.map((island,i)=>{
        const button=document.createElement('button');button.type='button';button.className='island-marker';
        button.style.setProperty('--island-tint',island.color);
        button.setAttribute('aria-label',`前往島嶼 ${island.key}：${island.title}`);
        button.innerHTML=`<span class="island-letter">${island.key}</span><span class="island-caption">島嶼 ${island.key}<small>${island.title}</small></span><span class="island-check" aria-hidden="true" hidden>✓</span>`;
        button.addEventListener('click',()=>this._choose(i));
        this.labelLayer.appendChild(button);return button;
      });
      this.canvas.style.touchAction='none';this.canvas.style.cursor='grab';
      this.canvas.setAttribute('role','img');
      this.canvas.setAttribute('aria-label','可旋轉的五座 3D 學習小島。拖曳旋轉、滾輪或雙指縮放，也可用島嶼按鈕前往。');
    }

    _listen() {
      const on=(target,name,fn,options)=>{target.addEventListener(name,fn,options);this.cleanups.push(()=>target.removeEventListener(name,fn,options));};
      on(this.canvas,'pointerdown',e=>{
        if(e.button!==0 && e.pointerType!=='touch') return;
        this.pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
        try{this.canvas.setPointerCapture(e.pointerId);}catch(_){}
        if(this.pointers.size===1) {this.start={x:e.clientX,y:e.clientY};this.moved=false;}
        else {this.moved=true;this.pinch=this._pinchDistance();}
        this.canvas.style.cursor='grabbing';
      });
      on(this.canvas,'pointermove',e=>{
        if(!this.pointers.has(e.pointerId)) return;
        const previous=this.pointers.get(e.pointerId);
        this.pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
        if(this.pointers.size>1) {
          const distance=this._pinchDistance();
          if(this.pinch>0) this.zoomLevel=clamp(this.zoomLevel*distance/this.pinch,.68,1.55);
          this.pinch=distance;this.moved=true;this._request();return;
        }
        const dx=e.clientX-previous.x,dy=e.clientY-previous.y;
        if(Math.hypot(e.clientX-this.start.x,e.clientY-this.start.y)>6) this.moved=true;
        if(this.moved) {this.yaw+=dx*.0065;this.pitch=clamp(this.pitch+dy*.0045,.39,1.13);this._request();}
      });
      const release=e=>{
        if(!this.pointers.has(e.pointerId)) return;
        const wasSingle=this.pointers.size===1;
        this.pointers.delete(e.pointerId);
        if(!this.pointers.size) {
          this.canvas.style.cursor='grab';
          if(wasSingle&&!this.moved&&e.type==='pointerup') {
            const rect=this.canvas.getBoundingClientRect();
            const hit=this._pick(e.clientX-rect.left,e.clientY-rect.top);
            if(hit>=0) this._choose(hit);
          }
        } else {this.moved=true;const point=[...this.pointers.values()][0];this.start={...point};}
      };
      on(this.canvas,'pointerup',release);on(this.canvas,'pointercancel',release);
      on(this.canvas,'wheel',e=>{e.preventDefault();this.zoom(-e.deltaY*.0013);},{passive:false});
      on(window,'resize',()=>this.resize());
      on(document,'visibilitychange',()=>{if(document.hidden&&this.travel){this.traveler=this.travel.to;this.travel=null;}if(!document.hidden)this._request();});
    }

    _pinchDistance(){const p=[...this.pointers.values()];return p.length<2?0:Math.hypot(p[0].x-p[1].x,p[0].y-p[1].y);}
    _choose(i){this.select(i);this.onSelect(i);}
    _travelerPosition(i){return add(ISLANDS[i].pos,[-.72,.13,.58]);}

    select(index,{animate=true}={}) {
      if(!Number.isInteger(index)||index<0||index>4) return;
      if(index===this.selected){
        if(!animate&&this.travel){this.traveler=this.travel.to;this.travel=null;}
        this._request();return;
      }
      const to=this._travelerPosition(index);
      if(index!==this.selected&&animate&&!this.low&&!document.hidden) this.travel={from:[...this.traveler],to,start:performance.now(),duration:720};
      else {this.travel=null;this.traveler=to;}
      this.selected=index;this._request();
    }
    setLowStimulus(value){this.low=!!value;if(this.low&&this.travel){this.traveler=this.travel.to;this.travel=null;}this._request();}
    setProgress(values){this.completed=ISLANDS.map((_,i)=>!!values[i]);this._request();}
    zoom(delta){this.zoomLevel=clamp(this.zoomLevel*Math.exp(clamp(delta,-.4,.4)),.68,1.55);this._request();}
    reset(){this.yaw=-.04;this.pitch=.71;this.zoomLevel=1;this._request();}
    resize(){
      const rect=this.canvas.getBoundingClientRect();
      this.width=Math.max(1,rect.width||this.canvas.parentElement.clientWidth||700);
      this.height=Math.max(1,rect.height||this.canvas.parentElement.clientHeight||600);
      const dpr=Math.min(window.devicePixelRatio||1,2);
      this.canvas.width=Math.round(this.width*dpr);this.canvas.height=Math.round(this.height*dpr);
      this.ctx.setTransform(dpr,0,0,dpr,0,0);this._request();
    }
    destroy(){this.dead=true;cancelAnimationFrame(this.frame);this.cleanups.forEach(fn=>fn());if(this.observer)this.observer.disconnect();this.labelLayer.replaceChildren();}
    _request(){if(!this.dead&&!this.frame)this.frame=requestAnimationFrame(t=>{this.frame=0;this._draw(t);});}

    _project(point){
      const [x,y,z]=point,cy=Math.cos(this.yaw),sy=Math.sin(this.yaw),cp=Math.cos(this.pitch),sp=Math.sin(this.pitch);
      const rx=x*cy-z*sy,rz=x*sy+z*cy,ry=y*cp-rz*sp,depth=y*sp+rz*cp;
      const base=Math.min(this.width/12.6,this.height/9.5),scale=base*15/(15-depth)*this.zoomLevel;
      return {x:this.width*.5+rx*scale,y:this.height*.44-ry*scale,z:depth,s:scale};
    }

    _pick(x,y){
      return ISLANDS.map((a,i)=>({i,p:this._project(add(a.pos,[0,.3,0]))})).sort((a,b)=>b.p.z-a.p.z)
        .find(({p})=>Math.pow((x-p.x)/(p.s*1.5),2)+Math.pow((y-p.y)/(p.s*1.65),2)<1)?.i??-1;
    }

    _tree(g,p,color,scale=1){
      g.cylinder(p,add(p,[0,.52*scale,0]),.065*scale,.045*scale,'#c8a78c',7);
      g.sphere(add(p,[0,.74*scale,0]),[.33*scale,.46*scale,.33*scale],color,9,6);
      g.sphere(add(p,[-.13*scale,.65*scale,.1*scale]),[.19*scale,.24*scale,.2*scale],color,8,5);
    }

    _buildWorld(){
      const g=new Geometry();
      ISLANDS.forEach((island,index)=>{
        const c=island.pos,point=(r,y,i)=>add(c,[Math.cos(i*TAU/12)*r*(1+.035*Math.sin(i*3.5+index)),y,Math.sin(i*TAU/12)*r*(1+.035*Math.sin(i*3.5+index))]);
        const palette=['#d9d0ec','#c4bddc','#bcbad9','#ddd5eb'];
        for(let i=0;i<12;i++) {
          const j=i+1;
          g.face([point(1.36,.15,i),point(1.36,.15,j),point(1.4,0,j),point(1.4,0,i)],island.color);
          g.face([add(c,[0,.15,0]),point(1.36,.15,i),point(1.36,.15,j)],island.color,true);
          g.face([point(1.14,-.54,j),point(1.14,-.54,i),point(1.4,0,i),point(1.4,0,j)],island.edge);
          g.face([point(1.14,-.54,j),point(.29,-1.35,(i+.5)),point(1.14,-.54,i)],palette[(i+index)%4]);
        }
        g.crystal(add(c,[.1,-1.68,-.04]),.27,.56,island.edge);
        // A curved, sandy path and tiny stepping stones make each place feel inhabited.
        g.cylinder(add(c,[.1,.16,.55]),add(c,[.1,.175,.55]),.52,.52,'#edf1df',16);
        [-.48,-.18,.12,.42].forEach((dx,i)=>g.sphere(add(c,[dx,.19,.88-i*.04]),[.13,.025,.09],'#f6f4e9',8,3));
        this._tree(g,add(c,[-.82,.15,-.46]),index===2?'#accccf':'#a8cdbb',.92);
        this._tree(g,add(c,[.79,.15,-.52]),index===3?'#e2b5ba':'#bed6c5',.66);
        g.sphere(add(c,[.94,.25,.25]),[.24,.16,.2],index===1?'#bbc5e2':'#b1ceb5',8,5);
        g.sphere(add(c,[.69,.23,.69]),[.14,.1,.12],'#f4eee4',8,4);
        g.sphere(add(c,[-1.02,.22,.17]),[.12,.08,.1],'#f1e3d2',8,4);
        const p=(x,y,z)=>add(c,[x,y,z]);
        if(index===0){
          // Three data boxes, with readable drawer fronts.
          g.box(p(.07,.39,-.03),[1.08,.44,.72],'#eee5d3');
          g.box(p(.13,.83,-.07),[.86,.43,.64],'#c7bfdf');
          g.box(p(.04,1.22,-.11),[.68,.35,.56],'#eee4be');
          [[.07,.39,.338,.66],[.13,.83,.255,.5],[.04,1.22,.175,.39]].forEach(([x,y,z,w])=>{
            g.box(p(x,y,z),[w,.16,.02],'#fffaf0');g.box(p(x,y,z+.014),[.14,.035,.015],'#aa98ba');
          });
          g.box(p(-.52,.36,.32),[.25,.38,.23],'#91bcb3');
        } else if(index===1){
          const hub=p(.05,.95,.08);
          [[-.4,.18,.42],[.5,.18,.37],[.12,.18,-.47]].forEach(a=>g.cylinder(p(...a),hub,.045,.045,'#9e95b4',8));
          const a=p(-.4,1.06,.22),b=p(.52,1.59,-.15),axis=norm(sub(b,a));
          g.cylinder(a,b,.23,.3,'#f6edd8',16);
          g.cylinder(add(b,mul(axis,-.1)),add(b,mul(axis,.1)),.33,.33,'#b0a6d0',16);
          g.cylinder(add(b,mul(axis,.105)),add(b,mul(axis,.115)),.255,.255,'#91c4d3',16);
          g.cylinder(add(a,mul(axis,-.17)),a,.12,.12,'#aaa0c2',12);
          g.box(p(.15,.42,.63),[.5,.16,.31],'#f4ddaa');
        } else if(index===2){
          g.cylinder(p(.05,.16,-.05),p(.05,.25,-.05),.67,.67,'#ece6f6',18);
          g.crystal(p(.12,.25,-.13),.43,1.5,'#b3d9e0');
          g.crystal(p(-.47,.2,.2),.26,.82,'#d4bde2');
          g.crystal(p(.58,.19,.28),.21,.62,'#f0d6c2');
          g.sphere(p(.13,1.95,-.13),[.085,.085,.085],'#eee2b7',8,5);
        } else if(index===3){
          g.box(p(.04,.23,-.06),[1.54,.15,.75],'#eee9e7');
          const heights=[.47,.78,1.09,1.42],colors=['#afcfc4','#b3cee1','#c5b8df','#edd8a4'];
          heights.forEach((h,i)=>{const x=-.52+i*.36;g.box(p(x,.3+h/2,-.05),[.27,h,.47],colors[i]);g.box(p(x,.3+h+.018,-.05),[.29,.035,.49],'#faf5e9');});
        } else {
          g.cylinder(p(.02,.17,-.03),p(.02,.35,-.03),.43,.43,'#b6accf',12);
          g.cylinder(p(.02,.35,-.03),p(.02,.72,-.03),.13,.11,'#e5bc7f',12);
          g.cylinder(p(.02,.67,-.03),p(.02,1.18,-.03),.22,.49,'#f0cf93',18,false);
          g.cylinder(p(.02,1.18,-.03),p(.02,1.23,-.03),.51,.51,'#ffe8b5',18);
          g.cylinder(p(.02,1.233,-.03),p(.02,1.24,-.03),.4,.4,'#e0b885',18);
          [-1,1].forEach(sign=>{
            for(let i=0;i<12;i++){
              const a=-Math.PI/2+i*Math.PI/12,b=-Math.PI/2+(i+1)*Math.PI/12;
              const point=t=>p(sign*(.38+Math.cos(t)*.29)+.02,.95+Math.sin(t)*.27,-.03);
              g.cylinder(point(a),point(b),.055,.055,'#edc68d',6);
            }
          });
          g.star(p(.03,1.64,-.03),.31,'#f4db9a');
        }
      });
      return g;
    }

    _buildTraveler(position){
      const g=new Geometry(),p=(x,y,z)=>add(position,[x,y,z]);
      // Cream space suit and a lavender visor; quiet and friendly, without blinking.
      g.sphere(p(0,.3,0),[.18,.24,.16],'#fffaf1',10,6);
      g.sphere(p(0,.64,.01),[.26,.25,.24],'#fffaf1',12,7);
      g.sphere(p(0,.65,.19),[.2,.145,.092],'#8c84af',12,6);
      g.sphere(p(-.065,.66,.266),[.022,.03,.012],'#f8f6ff',8,4);
      g.sphere(p(.065,.66,.266),[.022,.03,.012],'#f8f6ff',8,4);
      g.box(p(0,.33,-.17),[.23,.3,.16],'#acd0c3');
      g.cylinder(p(-.15,.39,0),p(-.25,.25,.04),.065,.06,'#f9f4eb',8);
      g.cylinder(p(.15,.39,0),p(.25,.29,.05),.065,.06,'#f9f4eb',8);
      [-.09,.09].forEach(x=>g.sphere(p(x,.08,.04),[.082,.11,.12],'#e4dded',8,5));
      g.box(p(0,.36,.151),[.1,.09,.025],'#d2b9df');
      g.cylinder(p(.15,.82,0),p(.17,.99,0),.016,.016,'#b5a8ca',5);
      g.sphere(p(.17,1.01,0),[.04,.04,.04],'#f0c7bd',7,4);
      return g;
    }

    _drawBackground(){
      const ctx=this.ctx,w=this.width,h=this.height;
      ctx.clearRect(0,0,w,h);
      if(!this.low){
        const gradient=ctx.createRadialGradient(w*.5,h*.5,0,w*.5,h*.5,Math.max(w,h)*.6);
        gradient.addColorStop(0,'rgba(226,224,245,.22)');gradient.addColorStop(1,'rgba(239,244,243,0)');
        ctx.fillStyle=gradient;ctx.fillRect(0,0,w,h);
        // Fixed quiet stars — decorative, never animated or twinkling.
        for(let i=0;i<18;i++) {
          const x=(.08+((i*47)%89)/100)*w,y=(.08+((i*29)%79)/100)*h,r=i%3===0?3:1.5;
          ctx.fillStyle=i%2?'#d9d4e7':'#d4e3dc';
          if(i%3===0){ctx.beginPath();ctx.moveTo(x,y-r);ctx.quadraticCurveTo(x,y,x+r,y);ctx.quadraticCurveTo(x,y,x,y+r);ctx.quadraticCurveTo(x,y,x-r,y);ctx.quadraticCurveTo(x,y,x,y-r);ctx.fill();}
          else{ctx.beginPath();ctx.arc(x,y,r,0,TAU);ctx.fill();}
        }
      }
      // Soft depth shadows projected below every floating island.
      ISLANDS.forEach(island=>{
        const p=this._project(add(island.pos,[0,-1.65,0]));
        ctx.save();ctx.translate(p.x,p.y);ctx.scale(1,.34);const r=p.s*1.28;
        const gr=ctx.createRadialGradient(0,0,0,0,0,r);gr.addColorStop(0,'rgba(118,105,156,.085)');gr.addColorStop(.65,'rgba(118,105,156,.025)');gr.addColorStop(1,'rgba(118,105,156,0)');ctx.fillStyle=gr;ctx.beginPath();ctx.arc(0,0,r,0,TAU);ctx.fill();ctx.restore();
      });
      if(!this.low){
        ctx.save();ctx.strokeStyle='#b8accb';ctx.globalAlpha=.33;ctx.lineWidth=1.5;ctx.setLineDash([3,9]);ctx.beginPath();
        for(let i=0;i<=100;i++){const a=i*TAU/100,p=this._project([Math.cos(a)*4.7,-.7,Math.sin(a)*4.2]);if(i===0)ctx.moveTo(p.x,p.y);else ctx.lineTo(p.x,p.y);}
        ctx.stroke();ctx.restore();
      }
    }

    _draw(now){
      if(this.dead||!this.ctx||this.width<2||this.height<2)return;
      if(this.travel){
        const t=clamp((now-this.travel.start)/this.travel.duration,0,1),e=t*t*(3-2*t);
        this.traveler=this.travel.from.map((v,i)=>mix(v,this.travel.to[i],e));this.traveler[1]+=Math.sin(Math.PI*t)*1.6;
        if(t===1){this.traveler=this.travel.to;this.travel=null;}else this._request();
      }
      this._drawBackground();
      const selection=new Geometry(),island=ISLANDS[this.selected];
      selection.ring(add(island.pos,[0,.165,0]),1.5,.018,'#a38fbd',64);
      // Opaque polygon painter with perspective depth sorting. Every face is actual 3D geometry.
      const faces=this.base.faces.concat(selection.faces,this._buildTraveler(this.traveler).faces).map(f=>{
        const ps=f.points.map(p=>this._project(p));return {fill:f.fill,ps,depth:ps.reduce((s,p)=>s+p.z,0)/ps.length};
      }).sort((a,b)=>a.depth-b.depth);
      const ctx=this.ctx;
      for(const face of faces){
        ctx.beginPath();face.ps.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();
        ctx.fillStyle=face.fill;ctx.strokeStyle=face.fill;ctx.lineWidth=.45;ctx.fill();ctx.stroke();
      }
      this.labels.forEach((button,i)=>{
        const p=this._project(add(ISLANDS[i].pos,[0,-1.48,.08]));
        const scale=clamp(p.s/56,.79,1.03);
        const x=clamp(p.x,68*scale,this.width-68*scale),y=clamp(p.y+8,8,this.height-56*scale-6);
        button.style.transform=`translate(${x}px,${y}px) translateX(-50%) scale(${scale})`;
        button.style.zIndex=String(Math.round(p.z*10+100));button.setAttribute('aria-pressed',String(i===this.selected));
        button.querySelector('.island-check').hidden=!this.completed[i];
        button.setAttribute('aria-label',`前往島嶼 ${ISLANDS[i].key}：${ISLANDS[i].title}${this.completed[i]?'，已完成':''}`);
      });
    }
  }
  window.IslandScene=IslandScene;
})();
