# 重建單一 HTML

這個資料夾保存拆分後的網頁原始碼。一般上課或上傳 GitHub，不需要使用這裡。

1. 使用 Node.js 22 或更新版本。
2. 在此 `source` 資料夾執行 `npm run build`；不需要安裝其他相依套件。
3. 產生的 `source/index.html` 與 `source/dist/index.html` 內容相同。
4. 將新 `index.html` 複製到 GitHub 儲存庫的發布根目錄。

## 修改位置

- `src/curriculum.json`：五島教材、活動題目、正解與提示。
- `src/template.html`：固定介面與預設課堂連線 JSON。
- `src/style.css`：版面與色彩。
- `src/scene.js`：3D 島嶼幾何、旋轉與縮放。
- `src/app.js`：活動、進度、教師看板與音樂。
- `src/sync-config.js`：課堂服務設定、健康檢查及乾淨 HTML 匯出。

同步服務預設留白。可以在建置前修改 `src/template.html` 裡 `classroom-config` 的 `apiBase` 與 `studentPageUrl`，或在成品網頁使用「課堂連線設定」下載設定後的 HTML。

建置程式會自動加入乾淨的原始檔快照，供網頁下載功能使用。請修改這裡的來源再重建，避免只編輯成品 HTML 的一部分，導致畫面與匯出快照不一致。

若更改各島活動步驟總數，須一起調整 `app.js` 的 `STEPS`、同步設定的版本檢查，以及 `backend/api.mjs` 的 `MAX_STEPS`。本版為 `[4, 4, 3, 6, 3]`。
