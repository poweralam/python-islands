import { handleApi } from './api.mjs';

/** API-only Worker. Student-facing index.html is hosted on GitHub Pages. */
export default {
  async fetch(request, env) {
    const response = await handleApi(request, env);
    if (response) return response;
    const url = new URL(request.url);
    const headers = {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store',
      'x-content-type-options': 'nosniff',
      'referrer-policy': 'no-referrer'
    };
    if (url.pathname !== '/' || request.method !== 'GET') {
      return new Response(JSON.stringify({ error: '找不到這個操作。', code: 'NOT_FOUND' }), { status: 404, headers });
    }
    return new Response(JSON.stringify({
      app: 'alam-python-islands',
      service: 'classroom-sync',
      version: 1,
      health: '/api/health',
      message: '這是課堂同步服務。請從老師提供的 GitHub Pages 網址開啟學習網頁。'
    }), { headers });
  }
};
