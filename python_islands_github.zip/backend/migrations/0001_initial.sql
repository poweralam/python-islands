CREATE TABLE rooms (
  code TEXT PRIMARY KEY NOT NULL,
  name TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  password_salt TEXT NOT NULL,
  password_iterations INTEGER NOT NULL,
  closed INTEGER NOT NULL DEFAULT 0 CHECK (closed IN (0,1)),
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL
);
--> statement-breakpoint
CREATE INDEX rooms_expiry_idx ON rooms(expires_at);
--> statement-breakpoint
CREATE TABLE teacher_sessions (
  token_hash TEXT PRIMARY KEY NOT NULL,
  room_code TEXT NOT NULL REFERENCES rooms(code) ON DELETE CASCADE,
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL
);
--> statement-breakpoint
CREATE INDEX teacher_room_idx ON teacher_sessions(room_code);
--> statement-breakpoint
CREATE TABLE students (
  room_code TEXT NOT NULL REFERENCES rooms(code) ON DELETE CASCADE,
  student_id TEXT NOT NULL,
  device_hash TEXT,
  token_hash TEXT UNIQUE,
  current_island INTEGER NOT NULL DEFAULT 0 CHECK (current_island BETWEEN 0 AND 4),
  action_at INTEGER NOT NULL,
  joined_at INTEGER NOT NULL,
  last_seen INTEGER NOT NULL,
  PRIMARY KEY(room_code,student_id)
);
--> statement-breakpoint
CREATE TABLE island_progress (
  room_code TEXT NOT NULL,
  student_id TEXT NOT NULL,
  island INTEGER NOT NULL CHECK (island BETWEEN 0 AND 4),
  visited INTEGER NOT NULL DEFAULT 0 CHECK (visited IN (0,1)),
  completed INTEGER NOT NULL DEFAULT 0 CHECK (completed IN (0,1)),
  step INTEGER NOT NULL DEFAULT 0,
  attempts INTEGER NOT NULL DEFAULT 0,
  errors INTEGER NOT NULL DEFAULT 0,
  completed_at INTEGER,
  PRIMARY KEY(room_code,student_id,island),
  FOREIGN KEY(room_code,student_id) REFERENCES students(room_code,student_id) ON DELETE CASCADE
);
--> statement-breakpoint
CREATE TABLE rate_limits (
  key_hash TEXT PRIMARY KEY NOT NULL,
  window_start INTEGER NOT NULL,
  count INTEGER NOT NULL DEFAULT 0
);
