/**
 * Classroom progress API. No plaintext passwords or bearer tokens are stored.
 * Student IDs identify classroom records, not verified school identities.
 * SQL schema is managed through D1 migrations, never request-time DDL.
 */
const DAY = 86400000;
const ROOM_LIFETIME = 30 * DAY;
const TEACHER_LIFETIME = 12 * 3600000;
const PASSWORD_ITERATIONS = 100000;
const MAX_STEPS = [4, 4, 3, 6, 3];
const MAX_BODY = 20480;
const CODE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const enc = new TextEncoder();
class ApiError extends Error {
  constructor(status, message, code, retryAfter) { super(message); this.status = status; this.code = code; this.retryAfter = retryAfter; }
}
function fail(status, message, code, retryAfter) { throw new ApiError(status, message, code, retryAfter); }
function hex(bytes) { return [...new Uint8Array(bytes)].map(v => v.toString(16).padStart(2, '0')).join(''); }
function randomToken(bytes = 32) { return hex(crypto.getRandomValues(new Uint8Array(bytes))); }
async function digest(value) { return hex(await crypto.subtle.digest('SHA-256', enc.encode(value))); }
async function derivePassword(password, salt, iterations = PASSWORD_ITERATIONS) {
  const key = await crypto.subtle.importKey('raw', enc.encode(password), 'PBKDF2', false, ['deriveBits']);
  return hex(await crypto.subtle.deriveBits({ name: 'PBKDF2', salt: enc.encode(salt), iterations, hash: 'SHA-256' }, key, 256));
}
function constantTimeEqual(a, b) {
  let difference = a.length ^ b.length;
  for (let i = 0; i < Math.max(a.length, b.length); i++) difference |= (a.charCodeAt(i) || 0) ^ (b.charCodeAt(i) || 0);
  return difference === 0;
}
function roomCode(value) {
  if (typeof value !== 'string') fail(400, '請輸入六碼課堂代碼。', 'INVALID_CODE');
  const code = value.trim().toUpperCase();
  if (!/^[A-HJ-NP-Z2-9]{6}$/.test(code)) fail(400, '請輸入六碼課堂代碼。', 'INVALID_CODE');
  return code;
}
function studentId(value) {
  if (typeof value !== 'string' || !/^[A-Za-z0-9-]{1,24}$/.test(value.trim())) fail(400, '學號請填寫 1–24 個英文字母、數字或連字號。', 'INVALID_STUDENT_ID');
  return value.trim();
}
function passwordValue(value) {
  if (typeof value !== 'string' || value.length < 8 || value.length > 128) fail(400, '教師密碼需為 8–128 個字元。', 'INVALID_PASSWORD');
  return value;
}
function integer(value, max, label) {
  if (!Number.isInteger(value) || value < 0 || value > max) fail(400, `${label}格式不正確。`, 'INVALID_PROGRESS');
  return value;
}
function roomPublic(room) { return { code: room.code, name: room.name, closed: Boolean(room.closed), expiresAt: new Date(room.expires_at).toISOString() }; }
function emptyProgress() { return MAX_STEPS.map(() => ({ visited: false, completed: false, step: 0, attempts: 0, errors: 0, completedAt: null })); }
function progressRow(row) { return { visited: Boolean(row.visited), completed: Boolean(row.completed), step: row.step, attempts: row.attempts, errors: row.errors, completedAt: row.completed_at ? new Date(row.completed_at).toISOString() : null }; }
async function bodyJSON(request) {
  const declared = Number(request.headers.get('content-length'));
  if (declared > MAX_BODY) fail(413, '送出的資料太大。', 'BODY_TOO_LARGE');
  if (!request.headers.get('content-type')?.toLowerCase().includes('application/json')) fail(415, '請以 JSON 傳送資料。', 'JSON_REQUIRED');
  let length = 0, chunks = [];
  if (request.body) {
    const reader = request.body.getReader();
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      length += value.length;
      if (length > MAX_BODY) { await reader.cancel(); fail(413, '送出的資料太大。', 'BODY_TOO_LARGE'); }
      chunks.push(value);
    }
  }
  const bytes = new Uint8Array(length); let offset = 0;
  for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.length; }
  try {
    const value = JSON.parse(new TextDecoder().decode(bytes));
    if (!value || Array.isArray(value) || typeof value !== 'object') throw new Error();
    return value;
  } catch { fail(400, '資料格式不正確。', 'INVALID_JSON'); }
}
async function throttle(request, db, scope, limit, windowMs) {
  // CF-Connecting-IP is set by the platform. No raw IP is retained in D1.
  const ip = request.headers.get('CF-Connecting-IP') || 'local-preview';
  const key = await digest(`${scope}|${ip}`), now = Date.now();
  const row = await db.prepare(`INSERT INTO rate_limits (key_hash, window_start, count) VALUES (?, ?, 1)
    ON CONFLICT(key_hash) DO UPDATE SET
      count=CASE WHEN rate_limits.window_start <= ? THEN 1 ELSE rate_limits.count+1 END,
      window_start=CASE WHEN rate_limits.window_start <= ? THEN excluded.window_start ELSE rate_limits.window_start END
    RETURNING count, window_start`).bind(key, now, now - windowMs, now - windowMs).first();
  if (row.count > limit) fail(429, '操作太頻繁，請稍後再試。', 'RATE_LIMITED', Math.max(1, Math.ceil((row.window_start + windowMs - now) / 1000)));
}
async function cleanup(db) {
  const now = Date.now();
  await db.batch([
    db.prepare('DELETE FROM teacher_sessions WHERE expires_at < ?').bind(now),
    db.prepare('DELETE FROM rooms WHERE expires_at < ?').bind(now),
    db.prepare('DELETE FROM rate_limits WHERE window_start < ?').bind(now - DAY)
  ]);
}
async function roomByCode(db, code) {
  const room = await db.prepare('SELECT * FROM rooms WHERE code=?').bind(code).first();
  if (!room || room.expires_at <= Date.now()) fail(404, '課堂代碼不存在或課堂已到期。', 'ROOM_NOT_FOUND');
  return room;
}
async function teacherToken(db, room, now = Date.now()) {
  const token = randomToken();
  await db.prepare('INSERT INTO teacher_sessions(token_hash,room_code,created_at,expires_at) VALUES(?,?,?,?)')
    .bind(await digest(token), room.code, now, Math.min(now + TEACHER_LIFETIME, room.expires_at)).run();
  return token;
}
function bearer(request) {
  const value = request.headers.get('authorization') || '';
  if (!/^Bearer [a-f0-9]{64}$/.test(value)) fail(401, '請重新登入。', 'UNAUTHORIZED');
  return value.slice(7);
}
async function authTeacher(request, db, code) {
  const tokenHash = await digest(bearer(request));
  const row = await db.prepare(`SELECT r.* FROM teacher_sessions t JOIN rooms r ON r.code=t.room_code
    WHERE t.token_hash=? AND t.room_code=? AND t.expires_at>? AND r.expires_at>?`).bind(tokenHash, code, Date.now(), Date.now()).first();
  if (!row) fail(401, '教師登入已到期，或您沒有這個課堂的權限。', 'UNAUTHORIZED');
  return row;
}
async function authStudent(request, db, allowClosed = false) {
  const tokenHash = await digest(bearer(request));
  const row = await db.prepare(`SELECT s.*,r.name AS room_name,r.closed AS room_closed,r.expires_at AS room_expires
    FROM students s JOIN rooms r ON r.code=s.room_code WHERE s.token_hash=? AND r.expires_at>?`).bind(tokenHash, Date.now()).first();
  if (!row) fail(401, '學生連線已失效，請重新加入課堂。', 'UNAUTHORIZED');
  if (row.room_closed && !allowClosed) fail(409, '老師已暫停這個課堂，進度暫時保留在本機。', 'ROOM_CLOSED');
  return row;
}
async function loadProgress(db, code, id) {
  const progress = emptyProgress();
  const result = await db.prepare('SELECT * FROM island_progress WHERE room_code=? AND student_id=? ORDER BY island').bind(code, id).all();
  for (const row of result.results) progress[row.island] = progressRow(row);
  return progress;
}
function normaliseProgress(progress) {
  if (!Array.isArray(progress) || progress.length !== 5) fail(400, '進度需要包含五座島。', 'INVALID_PROGRESS');
  return progress.map((p, i) => {
    if (!p || typeof p !== 'object' || typeof p.visited !== 'boolean' || typeof p.completed !== 'boolean') fail(400, '進度格式不正確。', 'INVALID_PROGRESS');
    const step = integer(p.step, MAX_STEPS[i], '活動步驟');
    const attempts = integer(p.attempts, 1000000, '嘗試次數');
    const errors = integer(p.errors, attempts, '再練習次數');
    if (p.completed && step !== MAX_STEPS[i]) fail(400, '完成島嶼時，請傳送完整步驟。', 'INVALID_PROGRESS');
    return { visited: p.visited || step > 0 || p.completed, completed: p.completed, step, attempts, errors };
  });
}
async function route(request, env, url) {
  const db = env?.DB;
  if (!db) fail(503, '課堂同步服務尚未就緒，請先使用自由探索。', 'DATABASE_UNAVAILABLE');
  const method = request.method, path = url.pathname;
  if (path === '/api/health' && method === 'GET') {
    await db.prepare('SELECT code FROM rooms LIMIT 1').first();
    return { ok: true, app: 'alam-python-islands', version: 1, maxSteps: [...MAX_STEPS] };
  }
  if (path === '/api/rooms' && method === 'POST') {
    await throttle(request, db, 'create', 10, 3600000);
    const input = await bodyJSON(request);
    const password = passwordValue(input.password);
    if (typeof input.name !== 'string' || !input.name.trim() || input.name.trim().length > 60) fail(400, '課堂名稱請填寫 1–60 個字。', 'INVALID_NAME');
    const name = input.name.trim();
    await cleanup(db);
    const salt = randomToken(16), hash = await derivePassword(password, salt), now = Date.now();
    for (let retry = 0; retry < 5; retry++) {
      const random = crypto.getRandomValues(new Uint8Array(6));
      const code = [...random].map(b => CODE_ALPHABET[b % CODE_ALPHABET.length]).join('');
      const result = await db.prepare(`INSERT INTO rooms(code,name,password_hash,password_salt,password_iterations,created_at,expires_at)
        VALUES(?,?,?,?,?,?,?) ON CONFLICT(code) DO NOTHING`).bind(code, name, hash, salt, PASSWORD_ITERATIONS, now, now + ROOM_LIFETIME).run();
      if (result.meta.changes) {
        const room = { code, name, expires_at: now + ROOM_LIFETIME };
        return { code, name, teacherToken: await teacherToken(db, room, now), expiresAt: new Date(room.expires_at).toISOString() };
      }
    }
    fail(503, '暫時無法建立課堂，請稍後再試。', 'CREATE_RETRY');
  }
  if (path === '/api/teacher/login' && method === 'POST') {
    await throttle(request, db, 'teacher-login', 15, 300000);
    const input = await bodyJSON(request), code = roomCode(input.code);
    const supplied = typeof input.password === 'string' && input.password.length <= 128 ? input.password : '';
    const room = await db.prepare('SELECT * FROM rooms WHERE code=?').bind(code).first();
    // Same key derivation for unknown rooms avoids a cheap password-validation timing oracle.
    const candidate = await derivePassword(supplied, room?.password_salt || '00000000000000000000000000000000', room?.password_iterations || PASSWORD_ITERATIONS);
    if (!room || room.expires_at <= Date.now() || !constantTimeEqual(candidate, room.password_hash)) fail(401, '課堂代碼或教師密碼不正確，或課堂已到期。', 'LOGIN_FAILED');
    return { code: room.code, name: room.name, teacherToken: await teacherToken(db, room), expiresAt: new Date(room.expires_at).toISOString() };
  }
  if (path === '/api/teacher/progress' && method === 'GET') {
    const code = roomCode(url.searchParams.get('code'));
    const room = await authTeacher(request, db, code);
    const [studentResult, progressResult] = await db.batch([
      db.prepare('SELECT student_id,current_island,joined_at,last_seen,action_at FROM students WHERE room_code=? ORDER BY student_id COLLATE NOCASE').bind(code),
      db.prepare('SELECT * FROM island_progress WHERE room_code=? ORDER BY student_id,island').bind(code)
    ]);
    const maps = new Map();
    for (const row of progressResult.results) {
      if (!maps.has(row.student_id)) maps.set(row.student_id, emptyProgress());
      maps.get(row.student_id)[row.island] = progressRow(row);
    }
    return { room: roomPublic(room), students: studentResult.results.map(s => ({ studentId: s.student_id, currentIsland: s.current_island,
      progress: maps.get(s.student_id) || emptyProgress(), lastSeen: new Date(s.last_seen).toISOString(), lastActionAt: new Date(s.action_at).toISOString(), joinedAt: new Date(s.joined_at).toISOString() })), serverTime: new Date().toISOString() };
  }
  if (path === '/api/teacher/close' && method === 'POST') {
    const input = await bodyJSON(request), code = roomCode(input.code);
    await authTeacher(request, db, code);
    if (typeof input.closed !== 'boolean') fail(400, '請指定課堂開放狀態。', 'INVALID_STATUS');
    await db.prepare('UPDATE rooms SET closed=? WHERE code=?').bind(input.closed ? 1 : 0, code).run();
    return { ok: true, closed: input.closed };
  }
  if (path === '/api/teacher/password' && method === 'POST') {
    const input = await bodyJSON(request), code = roomCode(input.code);
    const room = await authTeacher(request, db, code), password = passwordValue(input.password);
    const salt = randomToken(16), hash = await derivePassword(password, salt), token = randomToken(), now = Date.now();
    await db.batch([
      db.prepare('UPDATE rooms SET password_hash=?,password_salt=?,password_iterations=? WHERE code=?').bind(hash, salt, PASSWORD_ITERATIONS, code),
      db.prepare('DELETE FROM teacher_sessions WHERE room_code=?').bind(code),
      db.prepare('INSERT INTO teacher_sessions(token_hash,room_code,created_at,expires_at) VALUES(?,?,?,?)').bind(await digest(token), code, now, Math.min(now + TEACHER_LIFETIME, room.expires_at))
    ]);
    return { ok: true, teacherToken: token };
  }
  if (path === '/api/teacher/reset-device' && method === 'POST') {
    const input = await bodyJSON(request), code = roomCode(input.code), id = studentId(input.studentId);
    await authTeacher(request, db, code);
    const result = await db.prepare('UPDATE students SET device_hash=NULL,token_hash=NULL WHERE room_code=? AND student_id=?').bind(code, id).run();
    if (!result.meta.changes) fail(404, '這個課堂中沒有此學號。', 'STUDENT_NOT_FOUND');
    return { ok: true };
  }
  if (path === '/api/join' && method === 'POST') {
    await throttle(request, db, 'student-join', 300, 60000);
    const input = await bodyJSON(request), code = roomCode(input.code), id = studentId(input.studentId);
    if (typeof input.deviceToken !== 'string' || !/^[A-Za-z0-9_-]{32,128}$/.test(input.deviceToken)) fail(400, '裝置識別無效，請重新開啟頁面。', 'INVALID_DEVICE');
    const room = await roomByCode(db, code);
    if (room.closed) fail(409, '老師已暫停這個課堂，請稍後加入。', 'ROOM_CLOSED');
    const deviceHash = await digest(input.deviceToken);
    // A high-entropy device secret re-derives the same bearer token after refresh.
    const token = await digest(`student-session:v1|${code}|${id}|${input.deviceToken}`), tokenHash = await digest(token), now = Date.now();
    await db.prepare(`INSERT INTO students(room_code,student_id,device_hash,token_hash,current_island,action_at,joined_at,last_seen)
      SELECT ?,?,?,?,0,?,?,? WHERE (SELECT COUNT(*) FROM students WHERE room_code=?)<200
      ON CONFLICT(room_code,student_id) DO NOTHING`).bind(code, id, deviceHash, tokenHash, now, now, now, code).run();
    // Conditional update protects simultaneous devices from both claiming one student ID.
    await db.prepare(`UPDATE students SET device_hash=?,token_hash=?,last_seen=?
      WHERE room_code=? AND student_id=? AND (device_hash IS NULL OR device_hash=?)`).bind(deviceHash, tokenHash, now, code, id, deviceHash).run();
    const student = await db.prepare('SELECT device_hash,current_island,action_at FROM students WHERE room_code=? AND student_id=?').bind(code, id).first();
    if (!student) fail(409, '這個課堂已達 200 人上限。', 'ROOM_FULL');
    if (student.device_hash !== deviceHash) fail(409, '此學號已在另一個裝置使用。請老師解除裝置綁定後再加入。', 'DEVICE_CONFLICT');
    return { studentToken: token, room: roomPublic(room), progress: await loadProgress(db, code, id), currentIsland: student.current_island, lastActionAt: new Date(student.action_at).toISOString() };
  }
  if (path === '/api/progress' && method === 'POST') {
    const student = await authStudent(request, db), input = await bodyJSON(request), now = Date.now();
    const currentIsland = integer(input.currentIsland, 4, '目前島嶼'), progress = normaliseProgress(input.progress);
    const parsedTime = Date.parse(input.actionAt);
    if (!Number.isFinite(parsedTime)) fail(400, '操作時間格式不正確。', 'INVALID_TIME');
    // Stale retries can increase progress but cannot rewind the current island.
    const actionAt = Math.min(parsedTime, now);
    progress[currentIsland].visited = true;
    const statements = [db.prepare(`UPDATE students SET
      current_island=CASE WHEN action_at<=? THEN ? ELSE current_island END,
      action_at=MAX(action_at,?),last_seen=? WHERE room_code=? AND student_id=? AND token_hash=?`)
      .bind(actionAt, currentIsland, actionAt, now, student.room_code, student.student_id, student.token_hash)];
    progress.forEach((p, i) => statements.push(db.prepare(`INSERT INTO island_progress(room_code,student_id,island,visited,completed,step,attempts,errors,completed_at)
      SELECT ?,?,?,?,?,?,?,?,? WHERE EXISTS(SELECT 1 FROM students WHERE room_code=? AND student_id=? AND token_hash=?)
      ON CONFLICT(room_code,student_id,island) DO UPDATE SET
      visited=MAX(island_progress.visited,excluded.visited),completed=MAX(island_progress.completed,excluded.completed),
      step=MAX(island_progress.step,excluded.step),attempts=MAX(island_progress.attempts,excluded.attempts),errors=MAX(island_progress.errors,excluded.errors),
      completed_at=COALESCE(island_progress.completed_at,excluded.completed_at)`)
      .bind(student.room_code, student.student_id, i, Number(p.visited), Number(p.completed), p.step, p.attempts, p.errors, p.completed ? now : null,
        student.room_code, student.student_id, student.token_hash)));
    const results = await db.batch(statements);
    if (!results[0].meta.changes) fail(401, '學生連線已失效，請重新加入課堂。', 'UNAUTHORIZED');
    return { ok: true, serverTime: new Date(now).toISOString() };
  }
  if (path === '/api/heartbeat' && (method === 'POST' || method === 'PUT')) {
    const student = await authStudent(request, db, true), now = Date.now();
    await db.prepare('UPDATE students SET last_seen=? WHERE room_code=? AND student_id=? AND token_hash=?').bind(now, student.room_code, student.student_id, student.token_hash).run();
    return { ok: true, closed: Boolean(student.room_closed), serverTime: new Date(now).toISOString() };
  }
  fail(404, '找不到這個操作。', 'NOT_FOUND');
}
/**
 * Cross-origin browser requests must match a configured HTTPS origin exactly.
 * Paths, query strings, credentials, wildcards and host-name suffix matching are
 * intentionally unsupported. Missing Origin does not bypass endpoint auth.
 */
function originAllowed(origin, ownOrigin, env) {
  if (origin == null || origin === ownOrigin) return true;
  if (origin === 'null') return env?.ALLOW_FILE_ORIGIN === 'true';
  if (typeof env?.ALLOWED_ORIGINS !== 'string') return false;
  return env.ALLOWED_ORIGINS.split(',').some(value => {
    const entry = value.trim();
    if (!entry || entry.includes('*')) return false;
    try {
      const candidate = new URL(entry);
      return candidate.protocol === 'https:' && !candidate.username && !candidate.password &&
        candidate.pathname === '/' && !candidate.search && !candidate.hash &&
        candidate.origin === entry && origin === entry;
    } catch { return false; }
  });
}
/** Return null outside /api/. The independent Worker supplies a small status page. */
export async function handleApi(request, env) {
  const url = new URL(request.url);
  if (!url.pathname.startsWith('/api/')) return null;
  const origin = request.headers.get('origin');
  const allowed = originAllowed(origin, url.origin, env);
  const headers = { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff', 'vary': 'Origin' };
  if (!allowed) return new Response(JSON.stringify({ error: '此來源無法使用課堂同步服務。', code: 'ORIGIN_REJECTED' }), { status: 403, headers });
  if (origin) headers['access-control-allow-origin'] = origin;
  if (request.method === 'OPTIONS') {
    headers['access-control-allow-methods'] = 'GET, POST, PUT, OPTIONS';
    headers['access-control-allow-headers'] = 'Content-Type, Authorization';
    headers['access-control-max-age'] = '600';
    return new Response(null, { status: 204, headers });
  }
  try { return new Response(JSON.stringify(await route(request, env, url)), { status: 200, headers }); }
  catch (error) {
    const known = error instanceof ApiError;
    if (known && error.retryAfter) headers['retry-after'] = String(error.retryAfter);
    // Never include database/crypto errors, submitted credentials or query text in a response.
    return new Response(JSON.stringify({ error: known ? error.message : '同步服務暫時忙碌，請稍後再試。', code: known ? error.code : 'SERVICE_ERROR' }), { status: known ? error.status : 503, headers });
  }
}
